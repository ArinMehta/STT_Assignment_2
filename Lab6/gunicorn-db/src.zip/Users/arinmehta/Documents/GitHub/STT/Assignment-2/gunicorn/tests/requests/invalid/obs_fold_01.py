from gunicorn.http.errors import ObsoleteFolding

request = ObsoleteFolding
